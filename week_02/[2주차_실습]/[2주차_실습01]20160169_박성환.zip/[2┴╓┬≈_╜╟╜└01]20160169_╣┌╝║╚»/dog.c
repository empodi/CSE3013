#include "animal.h"

void dog(){
    printf("DOG!! \n");
    }
