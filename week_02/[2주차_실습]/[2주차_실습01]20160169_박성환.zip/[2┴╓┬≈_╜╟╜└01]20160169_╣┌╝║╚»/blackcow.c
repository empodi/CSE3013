#include "animal.h"

void blackcow(){
    printf("BLACKCOW!! \n");
}
