#include "animal.h"

int main(){
    dog();
    blackcow();
    turtle();
}
