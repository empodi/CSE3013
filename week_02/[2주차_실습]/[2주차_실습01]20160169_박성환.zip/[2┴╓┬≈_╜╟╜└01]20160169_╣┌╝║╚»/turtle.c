#include "animal.h"

void turtle(){
    printf("TURTLE!! \n");
}
